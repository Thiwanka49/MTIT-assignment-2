package com.example.enrollmentservice.service;

import com.example.enrollmentservice.entity.Enrollment;
import com.example.enrollmentservice.repository.EnrollmentRepository;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;

    public EnrollmentService(EnrollmentRepository enrollmentRepository) {
        this.enrollmentRepository = enrollmentRepository;
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepository.findAll();
    }

    public Enrollment getEnrollmentById(Long id) {
        return enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Enrollment not found"));
    }

    public Enrollment createEnrollment(Enrollment enrollment) {
        enrollment.setId(null);
        return enrollmentRepository.save(enrollment);
    }

    public Enrollment updateEnrollment(Long id, Enrollment updatedEnrollment) {
        Enrollment existing = getEnrollmentById(id);
        existing.setStudentId(updatedEnrollment.getStudentId());
        existing.setCourseId(updatedEnrollment.getCourseId());
        existing.setEnrollmentDate(updatedEnrollment.getEnrollmentDate());
        existing.setStatus(updatedEnrollment.getStatus());
        return enrollmentRepository.save(existing);
    }

    public void deleteEnrollment(Long id) {
        try {
            enrollmentRepository.deleteById(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Enrollment not found");
        }
    }
}
